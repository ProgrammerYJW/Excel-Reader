package test;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcelReaderApplication {

    public static void main(String[] args){
        SpringApplication.run(ExcelReaderApplication.class,args);
    }
}
