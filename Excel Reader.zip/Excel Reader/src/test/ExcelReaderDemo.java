package test;

import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Map;
import java.util.List;

public class ExcelReaderDemo {

    public List<String> data(String path){
        File file=new File(path);
        List<String> resultlines=new LinkedList<>();
        try(Workbook workbook= WorkbookFactory.create(file)){
            int sheetcount=workbook.getNumberOfSheets();
            if(sheetcount==0){
                resultlines.add("该Excel文件中无工作簿");
                return resultlines;
            }
            int i=1;
            for(Sheet sheet:workbook){
                resultlines.add("---工作簿"+i+": "+sheet.getSheetName()+"---");
                for(Row row:sheet){
                    StringBuilder rowbuilder=new StringBuilder();
                    Boolean rowhasdata=false;
                    for(Cell cell:row){
                        DataFormatter dataFormatter=new DataFormatter();
                        String cellcontent=dataFormatter.formatCellValue(cell).trim();
                        rowbuilder.append(cellcontent);
                        rowbuilder.append("   ");
                    }
                    if(!rowbuilder.isEmpty()){
                        rowhasdata=true;
                    }
                    if(rowhasdata==true){
                        String rowdata=rowbuilder.toString().trim();
                        resultlines.add(rowdata);
                    }
                }
                i++;
                if(i<workbook.getNumberOfSheets()){
                    resultlines.add("");
                }
            }

        }catch (IOException e){
            List<String> newlist=new LinkedList<>();
            newlist.add("出现异常，请重试");
            return newlist;
        }catch (Exception e){
            List<String> newlist=new LinkedList<>();
            newlist.add("出现异常，请重试");
            return newlist;
        }
        return resultlines;
    }
}
