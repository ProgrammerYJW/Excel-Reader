package test;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/test2")
public class ExcelReaderController {

    @PostMapping("/read")
    public Map<String, Object> query(
            @RequestBody @Valid Map<String,String> request
    ){
        Map<String, Object> answer=new HashMap<>();
        String path=request.get("path");
        if(path==null||path.trim().isEmpty()){
            answer.put("code",404);
            answer.put("data","路径不能为空，请重试");
            answer.put("success",false);
            return answer;
        }
        ExcelReaderDemo excelReaderDemo=new ExcelReaderDemo();
        List<String> datalines=excelReaderDemo.data(path);
        if(datalines.size()==1&& datalines.get(0).trim().contains("出现异常")){
            answer.put("code",404);
            answer.put("data",datalines);
            answer.put("success",false);
            return answer;
        }
        answer.put("code",200);
        answer.put("data",datalines);
        answer.put("success",true);
        return answer;
    }


}
